#!/usr/bin/env python3
"""Pixel Forge Studio — static site builder (Phase 1)."""
import os, pathlib

OUT = pathlib.Path(__file__).parent
WA = "919620024812"

NAVLINKS = [
    ("index.html", "Home"), ("services.html", "Services"), ("packages.html", "Packages"),
    ("add-ons.html", "Add-ons"), ("work.html", "Work"), ("about.html", "About"),
    ("process.html", "Process"), ("faq.html", "FAQ"), ("contact.html", "Contact"),
]

def head(title, desc, page):
    return f"""<!DOCTYPE html>
<html lang="en" data-theme="gold">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>{title}</title>
<meta name="description" content="{desc}">
<meta name="theme-color" content="#0A0908">
<meta property="og:title" content="{title}">
<meta property="og:description" content="{desc}">
<meta property="og:type" content="website">
<meta property="og:url" content="https://pixelforgestudio.com/{page}">
<meta name="robots" content="index, follow, max-image-preview:large">
<link rel="canonical" href="https://pixelforgestudio.com/{page}">
<link rel="manifest" href="manifest.json">
<link rel="icon" href="assets/img/icon-192.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body data-page="{page}">
"""

def nav(page):
    links = "".join(
        f'<a href="{h}" class="{"on" if h==page else ""}">{t}</a>' for h, t in NAVLINKS
    )
    return f"""<header class="nav">
  <div class="wrap nav-in">
    <a href="index.html" class="brand">
      <span class="brand-mark"><svg viewBox="0 0 24 24"><path d="M4 20 L12 4 L20 20"/><path d="M8 14 H16"/></svg></span>
      <span>Pixel Forge<small>Studio · Bengaluru</small></span>
    </a>
    <nav class="links">{links}</nav>
    <div class="nav-cta">
      <a class="btn btn-primary btn-sm" href="contact.html">Free mockup</a>
      <button class="burger" id="burger" aria-label="Menu"><i></i><i></i><i></i></button>
    </div>
  </div>
</header>
"""

def footer():
    return f"""<footer>
  <div class="wrap">
    <div class="f-grid">
      <div class="f-brand">
        <a href="index.html" class="brand">
          <span class="brand-mark"><svg viewBox="0 0 24 24"><path d="M4 20 L12 4 L20 20"/><path d="M8 14 H16"/></svg></span>
          <span>Pixel Forge<small>Studio · Bengaluru</small></span>
        </a>
        <p>Modern websites, Forged In 7 Days. Studio-grade design and modern engineering — and everything is yours.</p>
        <div class="socials">
          <a href="#" aria-label="Instagram"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1"/></svg></a>
          <a href="#" aria-label="Facebook"><svg viewBox="0 0 24 24"><path d="M15 3h-3a4 4 0 0 0-4 4v3H5v4h3v7h4v-7h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
          <a href="#" aria-label="LinkedIn"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 10v7M8 7v.01M12 17v-4a2 2 0 0 1 4 0v4"/></svg></a>
          <a href="#" aria-label="YouTube"><svg viewBox="0 0 24 24"><rect x="2" y="5" width="20" height="14" rx="4"/><path d="M10 9l5 3-5 3z"/></svg></a>
          <a href="#" aria-label="Google Business"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg></a>
        </div>
      </div>
      <div class="f-col"><h5>Build</h5>
        <a href="services.html">Services</a><a href="packages.html">Packages</a>
        <a href="add-ons.html">Add-ons</a><a href="process.html">Process</a></div>
      <div class="f-col"><h5>Studio</h5>
        <a href="work.html">Our work</a><a href="about.html">About</a>
        <a href="faq.html">FAQ</a><a href="contact.html">Contact</a></div>
      <div class="f-col"><h5>Legal</h5>
        <a href="privacy.html">Privacy Policy</a><a href="refund.html">Refund Policy</a>
        <a href="terms.html">Terms of Service</a></div>
    </div>
    <div class="f-bot">
      <span>© 2026 Pixel Forge Studio · No 53, 5th House B Street, Shivajinagar, Broadway, Bengaluru 560051</span>
      <span>Udyam Registered · UDYAM-KA-03-0460058 · hello@pixelforgestudio.com</span>
    </div>
  </div>
</footer>
"""

def floats():
    return f"""<a class="wa" href="https://wa.me/{WA}?text=Hi%20Faisal%2C%20I%20want%20a%20website." target="_blank" rel="noopener">
  <svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 2a8 8 0 1 1-4.2 14.8l-.4-.2-2.6.7.7-2.5-.2-.4A8 8 0 0 1 12 4zm-3 4c-.3 0-.7.1-.9.4-.3.4-.8 1-.8 1.9s.7 1.9 1 2.3c.3.4 1.6 2.5 4 3.4 2 .8 2.4.6 2.9.6.4 0 1.3-.5 1.5-1s.2-1 .2-1.1c-.1-.1-.3-.2-.6-.3l-1.4-.7c-.2-.1-.4-.1-.5.1l-.6.8c-.1.2-.3.2-.5.1a6.6 6.6 0 0 1-1.9-1.2 7 7 0 0 1-1.3-1.6c-.1-.2 0-.4.1-.5l.4-.5c.1-.2.1-.3 0-.5l-.6-1.4c-.1-.3-.3-.3-.5-.3z"/></svg>
  WhatsApp
</a>
<div class="botwrap">
  <div class="botpanel" id="botpanel">
    <div class="bot-head">
      <span class="av"><svg viewBox="0 0 24 24"><rect x="4" y="7" width="16" height="12" rx="3"/><path d="M12 3v4M9 13h.01M15 13h.01"/></svg></span>
      <span><b>Pixel Forge Assistant</b><small>● Online · replies instantly</small></span>
    </div>
    <div class="botlog" id="botlog"></div>
    <form class="botform" id="botform">
      <input id="botinput" placeholder="Ask about pricing, timelines…" autocomplete="off">
      <button type="submit" aria-label="Send"><svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button>
    </form>
    <div class="bot-foot"><a href="https://wa.me/{WA}" target="_blank" rel="noopener">Talk to Faisal on WhatsApp →</a></div>
  </div>
  <button class="botbtn" id="botbtn" aria-label="Open assistant"><svg viewBox="0 0 24 24"><rect x="4" y="7" width="16" height="12" rx="3"/><path d="M12 3v4M9 13h.01M15 13h.01"/></svg></button>
</div>
<div class="themedock" id="themedock">
  <button data-t="ember" style="background:#E8590C" title="Ember"></button>
  <button data-t="brass" style="background:#C9A227" title="Brass"></button>
  <button data-t="teal"  style="background:#14B8A6" title="Teal"></button>
  <button data-t="cobalt" style="background:#4F7DFF" title="Cobalt"></button>
  <button data-t="copper" style="background:#B87333" title="Copper"></button>
  <button data-t="ivory" style="background:#F7F4ED" title="Ivory"></button>
</div>
<script src="assets/js/main.js" defer></script>
</body>
</html>"""

def page(filename, title, desc, body, active):
    html = head(title, desc, active) + nav(active) + body + footer() + floats()
    (OUT / filename).write_text(html, encoding="utf-8")
    return filename

def sec_head(num, h2, p=""):
    return f'<div class="sec-head rv"><span class="num">{num}</span><h2>{h2}</h2>' + (f'<p>{p}</p>' if p else '') + '</div>'

# ---------------------------------------------------------------- HOME
def build_home():
    b = f"""
<main>
<section class="hero">
  <div class="grid-bg"></div>
  <div class="glow" style="width:720px;height:720px;top:-340px;right:-180px"></div>
  <div class="wrap" style="position:relative;z-index:2">
    <span class="eyebrow"><span class="dot"></span>Bengaluru · Websites, CRMs & Apps</span>
    <h1 class="hero-title"><span class="w" style="animation-delay:.05s">Modern</span> <span class="w" style="animation-delay:.14s">Websites,</span><br><span class="grad"><span class="w" style="animation-delay:.26s">Forged</span> <span class="w" style="animation-delay:.34s">In</span> <span class="w" style="animation-delay:.42s">7</span> <span class="w" style="animation-delay:.50s">Days.</span></span></h1>
    <p class="hero-sub">Studio-grade design and modern engineering. Live in a week. Every file, every account, every key — yours.</p>
    <div class="hero-actions">
      <a class="btn btn-primary" href="contact.html">Get a free homepage <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
      <a class="btn btn-ghost" href="packages.html">See packages &amp; pricing</a>
    </div>
    <div class="chips">
      <span class="chip"><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg>Live in 7 days</span>
      <span class="chip"><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg>You own everything</span>
      <span class="chip"><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg>AI assistant included</span>
      <span class="chip"><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg>No hidden costs</span>
      <span class="chip"><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg>Udyam registered</span>
    </div>

    <div class="mock rv" data-d="120">
      <div class="mock-bar"><i></i><i></i><i></i><span class="mock-url">pixelforgestudio.com</span></div>
      <div class="mock-body">
        <div class="mock-code">
<span class="c">// your-site.tsx</span><br>
<span class="k">export default</span> <span class="k">function</span> Site() {{<br>
&nbsp;&nbsp;<span class="k">return</span> (<br>
&nbsp;&nbsp;&nbsp;&nbsp;&lt;Hero<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;title=<span class="s">"Indiranagar Dental"</span><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;book=<span class="s">"whatsapp"</span><br>
&nbsp;&nbsp;&nbsp;&nbsp;/&gt;<br>
&nbsp;&nbsp;);<br>
}}<br>
<span class="c">// deployed in 7 days ✓</span><span class="cur"></span>
        </div>
        <div class="mock-prev">
          <span class="lbl">Live preview</span>
          <span class="big">Indiranagar<br>Dental Care</span>
          <span class="bar a"></span><span class="bar b"></span><span class="bar c"></span>
          <span class="pill">Book on WhatsApp</span>
        </div>
      </div>
    </div>
  </div>
</section>

<div class="marquee">
  <div class="marquee-track">
    <span>Next.js</span><span>·</span><span>React</span><span>·</span><span>TypeScript</span><span>·</span><span>Supabase</span><span>·</span><span>Cloudflare</span><span>·</span><span>PWA</span><span>·</span><span>Lighthouse 95+</span><span>·</span>
    <span>Next.js</span><span>·</span><span>React</span><span>·</span><span>TypeScript</span><span>·</span><span>Supabase</span><span>·</span><span>Cloudflare</span><span>·</span><span>PWA</span><span>·</span><span>Lighthouse 95+</span><span>·</span>
  </div>
</div>

<section class="sec">
  <div class="wrap">
    <div class="stats rv">
      <div class="stat"><b><em data-count="7">7</em></b><span>Days to launch</span></div>
      <div class="stat"><b><em data-count="767">767</em></b><span>Client reviews</span></div>
      <div class="stat"><b><em data-count="4.9" data-dec="1">4.9</em></b><span>Google rating</span></div>
      <div class="stat"><b><em data-count="100" data-suffix="%">100%</em></b><span>Ownership handed over</span></div>
    </div>
  </div>
</section>

<section class="sec sec-alt">
  <div class="wrap">
    {sec_head("01 — The problem", "A bad website costs you customers every single day.", "Not dramatically. Quietly. Someone searches for what you do, finds a page that takes six seconds to load, and taps back to Google. You never see them, and you never know.")}
    <div class="bento">
      <div class="card c-4 rv"><span class="n">THE OLD WAY</span><h3>Six weeks and two lakhs</h3><p>Agencies quote a quarter, deliver a template, and hand you a website you cannot edit without paying them again.</p></div>
      <div class="card c-4 rv" data-d="80"><span class="n">THE CHEAP WAY</span><h3>₹9,999 and it shows</h3><p>A theme with your logo dropped in. It loads slowly, ranks for nothing, and looks like every other shop on the street.</p></div>
      <div class="card c-4 rv" data-d="160" style="border-color:rgba(var(--ember-rgb),.35)"><span class="n">THE FORGE WAY</span><h3>Seven days, yours forever</h3><p>Designed for your business, engineered on a modern stack, handed over with every file and every account.</p></div>
    </div>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    {sec_head("02 — What we build", "Four things, done properly.", "Not twenty services sold badly. Four disciplines, each with a fixed price and a fixed delivery date.")}
    <div class="bento">
      <div class="card c-6 rv">
        <span class="ico"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="14" rx="2"/><path d="M3 9h18M8 21h8"/></svg></span>
        <span class="n">01</span><h3>Websites</h3>
        <p>Five to ten pages, custom-designed, mobile-first, with an AI assistant that answers your customers at 11pm. From ₹9,999.</p>
      </div>
      <div class="card c-6 rv" data-d="80">
        <span class="ico"><svg viewBox="0 0 24 24"><path d="M4 19V9M10 19V5M16 19v-7M22 19H2"/></svg></span>
        <span class="n">02</span><h3>CRM</h3>
        <p>Leads, pipeline, quotes, GST invoices — with an AI assistant living inside it. From ₹74,999.</p>
      </div>
      <div class="card c-6 rv" data-d="160">
        <span class="ico"><svg viewBox="0 0 24 24"><rect x="6" y="2" width="12" height="20" rx="3"/><path d="M11 18h2"/></svg></span>
        <span class="n">03</span><h3>Apps</h3>
        <p>Android or both stores. Login, payments, push notifications, AI built in. From ₹89,999.</p>
      </div>
      <div class="card c-6 rv" data-d="240">
        <span class="ico"><svg viewBox="0 0 24 24"><path d="M3 17l6-6 4 4 8-8"/><path d="M14 7h7v7"/></svg></span>
        <span class="n">04</span><h3>Marketing</h3>
        <p>Local SEO, Google Ads, social — with conversion tracking so you know which enquiry came from where.</p>
      </div>
    </div>
  </div>
</section>

<section class="sec sec-alt">
  <div class="wrap">
    {sec_head("03 — How it works", "Five steps. Seven days.", "The clock starts when we have your content and photos. Everything before that is free.")}
    <div class="pipe rv">
      <div class="pipe-step"><span class="n">01</span><h4>Free mockup</h4><p>We design your homepage before you pay. 48 hours.</p></div>
      <div class="pipe-step"><span class="n">02</span><h4>Agree</h4><p>Fixed price, fixed date, in writing. 1 day.</p></div>
      <div class="pipe-step"><span class="n">03</span><h4>Forge</h4><p>Design, build, content, tracking. 4 days.</p></div>
      <div class="pipe-step"><span class="n">04</span><h4>Review</h4><p>Two rounds of changes. 1 day.</p></div>
      <div class="pipe-step"><span class="n">05</span><h4>Handover</h4><p>Live, with every file and key. 1 day.</p></div>
    </div>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    {sec_head("04 — Our work", "One client. Live today.", "We do not show you a wall of logos. We show you one business we transformed, which you can open on your phone right now.")}
    <div class="bento">
      <div class="card c-8 rv" style="padding:0;overflow:hidden">
        <div style="display:grid;grid-template-columns:1fr 1fr;min-height:280px">
          <div style="background:linear-gradient(160deg,#1B1512,#0C0A09);padding:18px;display:flex;flex-direction:column;justify-content:center;border-right:1px solid var(--line)">
            <div style="background:#080706;border:1px solid var(--line);border-radius:9px;overflow:hidden">
              <div style="display:flex;gap:4px;padding:7px 9px;border-bottom:1px solid var(--line)"><i style="width:5px;height:5px;border-radius:50%;background:#5A2A1A;display:block"></i><i style="width:5px;height:5px;border-radius:50%;background:#2E2822;display:block"></i><i style="width:5px;height:5px;border-radius:50%;background:#2E2822;display:block"></i></div>
              <div style="padding:16px 14px">
                <div style="font-family:'JetBrains Mono';font-size:.5rem;color:var(--ember);letter-spacing:.12em">HALASURU · BENGALURU</div>
                <div style="font-family:'Space Grotesk';font-weight:700;font-size:1.05rem;line-height:1.1;margin:7px 0 9px;letter-spacing:-.02em">Bring your device<br>back to life.</div>
                <div style="height:4px;border-radius:2px;background:linear-gradient(90deg,var(--ember),var(--ember-soft));width:72%;margin-bottom:5px"></div>
                <div style="height:4px;border-radius:2px;background:var(--line);width:52%;margin-bottom:5px"></div>
                <div style="height:4px;border-radius:2px;background:var(--line);width:64%;margin-bottom:11px"></div>
                <div style="display:inline-block;font-size:.52rem;padding:5px 11px;border-radius:99px;background:var(--ember);color:#fff;font-weight:600">Book a repair</div>
              </div>
            </div>
          </div>
          <div style="padding:26px">
            <span class="mono" style="color:var(--ember)">CASE STUDY</span>
            <h3 style="margin:10px 0 8px">Red Apple Mobile Repair</h3>
            <p style="font-size:.86rem">Independent Apple device repair lab, Indiranagar. Conversion-focused website and Google Ads with full conversion tracking. Live in seven days.</p>
            <div style="display:flex;gap:20px;margin-top:16px">
              <div><b style="font-family:'Space Grotesk';font-size:1.3rem;color:var(--ember)">4.9</b><span style="display:block;font-size:.66rem;color:var(--ash-2)">Google rating</span></div>
              <div><b style="font-family:'Space Grotesk';font-size:1.3rem;color:var(--ember)">767</b><span style="display:block;font-size:.66rem;color:var(--ash-2)">Reviews</span></div>
              <div><b style="font-family:'Space Grotesk';font-size:1.3rem;color:var(--ember)">7</b><span style="display:block;font-size:.66rem;color:var(--ash-2)">Days to live</span></div>
            </div>
          </div>
        </div>
      </div>
      <div class="card c-4 rv" data-d="80" style="display:flex;flex-direction:column;justify-content:center">
        <span class="n">MORE COMING</span>
        <h3>Your business next</h3>
        <p style="margin-bottom:16px">We are a new studio. That is why we offer the free mockup — so you can judge the work before you commit a rupee.</p>
        <a class="btn btn-ghost btn-sm" href="work.html">Read the case study</a>
      </div>
    </div>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    <div class="offer rv">
      <span class="eyebrow" style="margin-bottom:18px"><span class="dot"></span>No card. No commitment.</span>
      <h2>See your homepage before you pay.</h2>
      <p>Send us your business name and what you do. We design a real homepage for it — your services, your colours, your city — and send it within 48 hours. If you love it, we build the rest. If not, you keep it anyway.</p>
      <div class="hero-actions" style="justify-content:center;margin-bottom:0">
        <a class="btn btn-primary" href="https://wa.me/{WA}?text=Hi%20Faisal%2C%20I%27d%20like%20a%20free%20homepage%20design." target="_blank" rel="noopener">Request on WhatsApp</a>
        <a class="btn btn-ghost" href="packages.html">See what it costs</a>
      </div>
    </div>
  </div>
</section>

<section class="sec sec-alt">
  <div class="wrap" style="max-width:860px">
    {sec_head("05 — Questions", "The ones we get most.")}
    <div class="faq">
      <div class="faq-item"><button class="faq-q">How can you deliver in seven days when agencies take six weeks?<span class="pm">+</span></button><div class="faq-a"><p>Because we have removed everything that makes projects slow: no committee, no handoffs between three teams, no waiting on a designer in another timezone. One studio, one design system, one build. The clock starts when we have your content — not when you sign.</p></div></div>
      <div class="faq-item"><button class="faq-q">What if I do not like the design?<span class="pm">+</span></button><div class="faq-a"><p>You will see a real homepage before you pay anything. If it is not right, you keep it and we part as friends. If we have started a paid build and you are unhappy at the review stage, you get two full rounds of changes, and if it is still wrong we refund the balance.</p></div></div>
      <div class="faq-item"><button class="faq-q">Do I own the website and the code?<span class="pm">+</span></button><div class="faq-a"><p>Completely. Source code, repository, domain, hosting, analytics, Google Ads — all registered in your name. There is no lock-in and no fee to keep your own site. If you ever want to move to another developer, you hand them the keys.</p></div></div>
      <div class="faq-item"><button class="faq-q">What happens after seven days?<span class="pm">+</span></button><div class="faq-a"><p>Three months of care is included free — uptime monitoring, backups, security patches and content updates. After month three it continues at ₹2,499 a month, and only if you want it. No auto-renewal.</p></div></div>
    </div>
    <div style="text-align:center;margin-top:34px"><a class="btn btn-ghost" href="faq.html">All questions →</a></div>
  </div>
</section>
</main>
"""
    return page("index.html", "Pixel Forge Studio — Modern websites, Forged In 7 Days",
                "Bengaluru studio building websites, CRMs and apps in seven days. Free homepage design in 48 hours. You own everything.", b, "index.html")

# ---------------------------------------------------------------- SERVICES
CATS = [
 ("hotel","Hotels & Homestays","Direct bookings, no OTA commission"),
 ("salon","Salons & Spas","Online booking, fewer no-shows"),
 ("retail","Retail Shops","Catalogue, WhatsApp orders, footfall"),
 ("clinic","Clinics & Hospitals","Appointments and patient trust"),
 ("realestate","Real Estate","Listings and enquiry capture"),
 ("lawyer","Lawyers & Consultants","Credibility, consultation bookings"),
 ("portfolio","Portfolios & Creators","Work that gets you hired"),
 ("event","Event Management","Enquiry forms and galleries"),
 ("ecommerce","E-commerce","Payments, inventory, delivery"),
 ("agency","Agencies & B2B","Lead generation and case studies"),
]

def build_services():
    tiles = "".join(f"""
      <a class="tile rv" href="#{k}" data-d="{i*40}">
        <img src="assets/img/{k}.jpg" alt="{t} website design Bengaluru" loading="lazy">
        <div class="tile-body"><h4>{t}</h4><p>{d}</p></div>
      </a>""" for i,(k,t,d) in enumerate(CATS))

    detail = "".join(f"""
      <div id="{k}" style="padding:34px 0;border-bottom:1px solid var(--line)">
        <div style="display:grid;grid-template-columns:1fr 1.4fr;gap:32px;align-items:center">
          <img src="assets/img/{k}.jpg" alt="{t}" loading="lazy" style="border-radius:14px;aspect-ratio:3/2;object-fit:cover;filter:grayscale(.15)">
          <div>
            <span class="mono" style="color:var(--ember)">{t}</span>
            <h3 style="margin:9px 0 10px;font-size:1.35rem">{d}</h3>
            <p style="color:var(--ash);font-size:.92rem">A five-page site built for how {t.lower()} actually win customers — clear services, real prices, a WhatsApp button on every page, and an AI assistant that answers when you are closed.</p>
            <div class="chips" style="margin-top:14px">
              <span class="chip">From ₹9,999</span><span class="chip">7 days</span><span class="chip">Google profile setup</span>
            </div>
          </div>
        </div>
      </div>""" for k,t,d in CATS)

    b = f"""
<main>
<section class="hero" style="padding:64px 0 46px">
  <div class="grid-bg"></div>
  <div class="wrap" style="position:relative;z-index:2">
    <span class="eyebrow"><span class="dot"></span>Services</span>
    <h1 class="hero-title" style="font-size:clamp(2.2rem,4.6vw,3.6rem)">We build for<br><span class="grad">your kind of business.</span></h1>
    <p class="hero-sub">A salon and a steel manufacturer need completely different websites. Pick your category and see what we build for it.</p>
  </div>
</section>

<section class="sec" style="padding-top:20px">
  <div class="wrap"><div class="tiles">{tiles}</div></div>
</section>

<section class="sec sec-alt">
  <div class="wrap">
    {sec_head("Detail", "What each one gets.")}
    {detail}
  </div>
</section>

<section class="sec">
  <div class="wrap">
    <div class="offer rv">
      <h2>Not sure which one you need?</h2>
      <p>Tell us your business in one line. We will tell you what to build — even if the answer is "you do not need a website yet".</p>
      <a class="btn btn-primary" href="contact.html">Ask us</a>
    </div>
  </div>
</section>
</main>
"""
    return page("services.html","Services — websites for every business type | Pixel Forge Studio",
      "Websites for hotels, salons, retail, clinics, real estate, lawyers, portfolios, events, e-commerce and agencies. Bengaluru.", b, "services.html")

# ---------------------------------------------------------------- PACKAGES
def build_packages():
    def opt_core(val, title, desc, price, checked=False):
        return f'''<label class="opt"><input type="radio" name="core" value="{val}" {"checked" if checked else ""}>
          <span class="opt-body"><span class="opt-t">{title}</span><span class="opt-d">{desc}</span></span>
          <span class="opt-p">{price}</span></label>'''
    def opt_tier(val, title, desc, checked=False):
        return f'''<label class="opt"><input type="radio" name="tier" value="{val}" {"checked" if checked else ""}>
          <span class="opt-body"><span class="opt-t">{title}</span><span class="opt-d">{desc}</span></span>
          <span class="opt-p" data-tierprice="{val}">—</span></label>'''

    stacks = [
      ("Startup","1,49,999","Website Essential + CRM Essential + App Essential","8–10 weeks · 5 pages, no site bot, CRM max 5 users, Android only, one revision round",False),
      ("Growth","2,24,999","Website + CRM + App — all Professional","10–12 weeks · AI bot on site, PWA, both app stores, 3-month care",True),
      ("Scale","3,11,999","Website + CRM + App — all Complete","12–14 weeks · all 8 listings, reviews pack, reports, CMS",False),
      ("Elite","4,99,999","Website + CRM + App — all Elite","12–16 weeks · custom build, ERP, multi-role, 4-hour SLA",False),
    ]
    stackcards = "".join(f'''
      <div class="pcard {"hot" if hot else ""} rv" data-d="{i*70}">
        {"<span class='tag'>Most booked</span>" if hot else ""}
        <h4>{n} Stack</h4>
        <div class="amt">₹{p}<small> one-time</small></div>
        <p style="font-size:.76rem;color:var(--ash-2);margin:0">{d}</p>
        <ul><li>{x}</li></ul>
        <a class="btn {"btn-primary" if hot else "btn-ghost"} btn-block btn-sm" style="margin-top:16px" href="contact.html">Discuss this</a>
      </div>''' for i,(n,p,d,x,hot) in enumerate(stacks))

    b = f"""
<main>
<section class="hero" style="padding:64px 0 40px">
  <div class="grid-bg"></div>
  <div class="wrap" style="position:relative;z-index:2">
    <span class="eyebrow"><span class="dot"></span>Packages</span>
    <h1 class="hero-title" style="font-size:clamp(2.2rem,4.6vw,3.6rem)">Published prices.<br><span class="grad">No surprises.</span></h1>
    <p class="hero-sub">Build your own package below, or pick a stack. Every price includes design, deployment, SSL and three months of care.</p>
  </div>
</section>

<section class="sec" style="padding-top:16px">
  <div class="wrap">
    <div class="trip rv">
      <div>
        <span class="mono" style="color:var(--ember)">Entry · the only discounted product we sell</span>
        <h3 style="margin-top:8px">Tripwire — one page, Google listing, WhatsApp. Five days.</h3>
        <p>Bought separately this is ₹19,997. It is capped at one page and one revision, and it converts to a full build within 60 days with 70% of it credited back.</p>
      </div>
      <div class="amt">₹9,999<small>one-time</small></div>
    </div>

    <div class="cfg" id="cfg">
      <div>
        <div class="cfg-step">
          <div class="lbl"><i>1</i>What are you building?</div>
          <div class="opts" id="cfg-core">
            {opt_core("website","Website","Five to ten pages, AI assistant, mobile-first","from ₹19,999",True)}
            {opt_core("crm","CRM","Leads, pipeline, quotes, AI inside","from ₹74,999")}
            {opt_core("app","App","Android or both stores, AI built in","from ₹89,999")}
          </div>
        </div>
        <div class="cfg-step">
          <div class="lbl"><i>2</i>Pick your tier</div>
          <div class="opts" id="cfg-tier">
            {opt_tier("essential","Essential","The core product, done properly")}
            {opt_tier("professional","Professional","Adds the AI assistant and presence",True)}
            {opt_tier("complete","Complete","Everything, plus reporting")}
            {opt_tier("elite","Elite","Custom build, SLA, dedicated")}
          </div>
        </div>
        <div class="cfg-step">
          <div class="lbl"><i>3</i>Add what you need</div>
          <div class="opts" id="cfg-addons"></div>
        </div>
        <div class="cfg-step">
          <div class="lbl"><i>4</i>Monthly growth (optional)</div>
          <div class="opts" id="cfg-monthly"></div>
        </div>
      </div>
      <aside class="sum">
        <h4>Your build</h4>
        <div id="sum-lines"><div class="sum-empty">Pick a package to begin.</div></div>
        <div class="sum-tot">
          <div><span>One-time</span><b id="sum-total">₹0</b></div>
          <div id="sum-monthly-row" style="display:none"><span>Monthly</span><b class="mo" id="sum-monthly">—</b></div>
        </div>
        <a class="btn btn-primary btn-block" id="sum-send" href="#" target="_blank" rel="noopener" style="margin-top:14px">Send on WhatsApp</a>
        <p style="font-size:.66rem;color:var(--ash-2);text-align:center;margin:10px 0 0">No payment here. We reply with a written quote.</p>
      </aside>
    </div>
  </div>
</section>

<section class="sec sec-alt">
  <div class="wrap">
    {sec_head("Stacks", "Or take all three, and save.", "Buying the website, CRM and app together is cheaper than buying them one at a time — and one team, one timeline.")}
    <div class="price-grid">{stackcards}</div>
  </div>
</section>


<section class="sec sec-alt">
  <div class="wrap">
    {sec_head("Full price list", "Every number, on one screen.", "Nothing hidden behind a quote form. These are the prices.")}
    <table class="cmp">
      <thead><tr><th>Core product</th><th>Essential</th><th>Professional</th><th>Complete</th><th>Elite</th></tr></thead>
      <tbody>
        <tr><td>Website</td><td class="yes">₹19,999</td><td class="yes">₹29,999</td><td class="yes">₹49,999</td><td class="yes">₹89,999</td></tr>
        <tr><td>CRM</td><td class="yes">₹74,999</td><td class="yes">₹1,09,999</td><td class="yes">₹1,49,999</td><td class="yes">₹2,99,999</td></tr>
        <tr><td>App</td><td class="yes">₹89,999</td><td class="yes">₹1,39,999</td><td class="yes">₹1,99,999</td><td class="yes">₹3,99,999</td></tr>
        <tr><td>Entry — Tripwire (one page + Google + WhatsApp)</td><td class="yes">₹9,999</td><td class="no">—</td><td class="no">—</td><td class="no">—</td></tr>
      </tbody>
    </table>

    <h3 style="margin:34px 0 12px">Bundles — all three cores together</h3>
    <table class="cmp">
      <thead><tr><th>Stack</th><th>Tiers included</th><th>Bought separately</th><th>Bundle price</th><th>You save</th></tr></thead>
      <tbody>
        <tr><td>Startup</td><td>All Essential</td><td>₹1,84,997</td><td class="yes">₹1,49,999</td><td>₹34,998</td></tr>
        <tr><td>Growth</td><td>All Professional</td><td>₹2,79,997</td><td class="yes">₹2,24,999</td><td>₹54,998</td></tr>
        <tr><td>Scale</td><td>All Complete</td><td>₹3,99,997</td><td class="yes">₹3,11,999</td><td>₹87,998</td></tr>
        <tr><td>Elite</td><td>All Elite</td><td>₹7,89,997</td><td class="yes">₹4,99,999</td><td>₹2,89,998</td></tr>
      </tbody>
    </table>

    <h3 style="margin:34px 0 12px">Any two cores</h3>
    <p style="color:var(--ash);font-size:.9rem;margin-bottom:14px">Pick two of Website, CRM and App — <strong style="color:var(--ember)">12% off</strong> the combined list price.</p>
    <table class="cmp">
      <thead><tr><th>Combination</th><th>List</th><th>Bundle</th></tr></thead>
      <tbody>
        <tr><td>Website + CRM — Essential</td><td>₹94,998</td><td class="yes">₹83,999</td></tr>
        <tr><td>Website + CRM — Professional</td><td>₹1,39,998</td><td class="yes">₹1,23,999</td></tr>
        <tr><td>Website + CRM — Complete</td><td>₹1,99,998</td><td class="yes">₹1,75,999</td></tr>
        <tr><td>Website + CRM — Elite</td><td>₹3,89,998</td><td class="yes">₹3,43,999</td></tr>
        <tr><td>Website + App — Essential</td><td>₹1,09,998</td><td class="yes">₹96,999</td></tr>
        <tr><td>CRM + App — Essential</td><td>₹1,64,998</td><td class="yes">₹1,45,999</td></tr>
      </tbody>
    </table>

    <p style="color:var(--ash-2);font-size:.82rem;margin-top:20px">All prices exclude 18% GST. Every build includes design, deployment, SSL and three months of care. Add-ons and retainers are listed on the <a href="add-ons.html" style="color:var(--ember)">Add-ons</a> page.</p>
  </div>
</section>

<section class="sec">
  <div class="wrap">
    {sec_head("Compare", "What sits inside each tier.")}
    <table class="cmp">
      <thead><tr><th>Feature</th><th>Essential</th><th>Professional</th><th>Complete</th><th>Elite</th></tr></thead>
      <tbody>
        <tr><td>Custom design</td><td class="yes">Yes</td><td class="yes">Yes</td><td class="yes">Yes</td><td class="yes">Yes</td></tr>
        <tr><td>AI assistant</td><td class="no">—</td><td class="yes">Yes</td><td class="yes">Yes</td><td class="yes">Yes</td></tr>
        <tr><td>App install (PWA)</td><td class="no">—</td><td class="yes">Yes</td><td class="yes">Yes</td><td class="yes">Yes</td></tr>
        <tr><td>Google Business Profile</td><td class="no">—</td><td class="yes">Yes</td><td class="yes">Yes</td><td class="yes">Yes</td></tr>
        <tr><td>All 8 directory listings</td><td class="no">—</td><td class="no">—</td><td class="yes">Yes</td><td class="yes">Yes</td></tr>
        <tr><td>Reviews &amp; reputation pack</td><td class="no">—</td><td class="no">—</td><td class="yes">Yes</td><td class="yes">Yes</td></tr>
        <tr><td>Monthly reporting</td><td class="no">—</td><td class="no">—</td><td class="yes">Yes</td><td class="yes">Yes</td></tr>
        <tr><td>Care included</td><td>3 months</td><td>3 months</td><td>3 months</td><td>6 months</td></tr>
        <tr><td>Delivery</td><td>7 days</td><td>10 days</td><td>14 days</td><td>4–6 weeks</td></tr>
      </tbody>
    </table>
  </div>
</section>
</main>
"""
    return page("packages.html","Packages & pricing | Pixel Forge Studio",
      "Website, CRM and app packages from ₹9,999. Build your own package and see the price live.", b, "packages.html")

# ---------------------------------------------------------------- ADD-ONS
def build_addons():
    groups = [
      ("Digital presence", "One-time setup, priced separately from your build.", [
        ("Google Business Profile","Claim, verify, categories, photos, description","₹4,999"),
        ("Facebook Page","Setup, bio, cover design, first posts","₹2,999"),
        ("Instagram Page","Setup, bio, highlight covers, grid","₹2,999"),
        ("Facebook + Instagram","Both pages, bundled","₹4,999"),
        ("LinkedIn company page","Setup with content, not just a shell","₹2,999"),
        ("YouTube channel","Banner, about, playlists, 3 uploads","₹3,999"),
        ("Justdial listing","Verification, categories, photos, response setup","₹2,999"),
        ("IndiaMART seller profile","25 products with descriptions · platform fee at cost","₹4,999"),
        ("Sulekha listing","Service areas, lead inbox, templates","₹2,499"),
        ("WhatsApp Business","Catalogue, quick replies, labels, away messages","₹4,999"),
        ("WhatsApp Business API","Verified API, templates, flows","₹14,999"),
        ("Complete Online Profile","All 8 listings + WhatsApp + Google Business · saves ₹8,492","₹24,999"),
      ]),
      ("Analytics & advertising", "If you cannot measure it, you cannot improve it.", [
        ("Google Ads account + tracking","Account, campaigns, conversion events","₹4,999"),
        ("Meta Business Suite","Pixel, Conversions API, catalogue","₹4,999"),
        ("Bing Ads + Webmaster","Cheaper CPCs for B2B — nobody else offers this","₹2,999"),
        ("Google Merchant Center","Product feed, shopping setup","₹3,999"),
        ("GA4 + GTM + Search Console","Conversion events and a dashboard, not just a tag","₹4,999"),
        ("Reviews & Reputation Pack","QR, 10 reply templates, 30-day review campaign","₹7,999"),
      ]),
      ("AI & automation", "The part competitors do not sell at this price.", [
        ("Website AI bot","Trained on your business, answers 24/7, hands off to you","₹24,999"),
        ("WhatsApp AI bot","Answers, qualifies, books — on your verified number","₹34,999"),
        ("Bot integration (existing CRM)","Add a bot to Zoho, HubSpot or Salesforce you already own","₹14,999"),
        ("Voice bot setup","Answers inbound calls in English and Kannada","₹24,999"),
        ("AI bot running","API usage, monitoring, monthly tuning","₹2,499/mo"),
        ("Voice bot running","Call minutes, monitoring, tuning","₹9,999/mo"),
      ]),
      ("Care plans", "Included free for three months on every project. Continues only if you choose.", [
        ("Care Basic","Uptime monitoring, backups, security, 1 update a month","₹2,499/mo"),
        ("Care Plus","+ 3 updates, monthly report, bot running, priority support","₹4,999/mo"),
        ("Growth Care","+ SEO upkeep, 5 updates, Google Business posts, WhatsApp support","₹9,999/mo"),
        ("CRM Care","+ user support, bug fixes, 4 hours a month","₹7,499/mo"),
        ("Elite Care","+ 4-hour SLA, dedicated support, quarterly strategy, bot running","₹19,999/mo"),
      ]),
      ("Marketing retainers", "Monthly, cancel with 30 days notice.", [
        ("Local SEO","Google Business posts, content, citations, Search Console","₹19,999/mo"),
        ("SEO Growth","25+ keywords, technical work, content plan","₹29,999/mo"),
        ("Google Ads management","Campaigns, negative keywords, conversion tracking","₹14,999/mo"),
        ("Google + Meta Ads","Both platforms, one report","₹24,999/mo"),
        ("Social media","12 posts + 4 reels, captions, calendar","₹19,999/mo"),
        ("Email marketing","Sequences, newsletters, deliverability","₹9,999/mo"),
        ("Full Digital","SEO + Ads + Social together · saves ₹4,998","₹49,999/mo"),
      ]),
    ]
    blocks = ""
    for title, sub, rows in groups:
        trs = "".join(f'<tr><td>{a}</td><td>{b}</td><td style="text-align:right;font-family:\'JetBrains Mono\';color:var(--ember);white-space:nowrap">{c}</td></tr>' for a,b,c in rows)
        blocks += f"""<div class="rv" style="margin-bottom:44px">
          <h3 style="margin-bottom:6px">{title}</h3>
          <p style="color:var(--ash);font-size:.88rem;margin-bottom:16px">{sub}</p>
          <table class="cmp"><tbody>{trs}</tbody></table>
        </div>"""

    b = f"""
<main>
<section class="hero" style="padding:64px 0 40px">
  <div class="grid-bg"></div>
  <div class="wrap" style="position:relative;z-index:2">
    <span class="eyebrow"><span class="dot"></span>Add-ons</span>
    <h1 class="hero-title" style="font-size:clamp(2.2rem,4.6vw,3.6rem)">Everything else,<br><span class="grad">priced openly.</span></h1>
    <p class="hero-sub">Buy any of these on their own, or add them to a build. No "contact us for pricing".</p>
  </div>
</section>
<section class="sec" style="padding-top:16px">
  <div class="wrap" style="max-width:900px">{blocks}</div>
</section>
</main>
"""
    return page("add-ons.html","Add-ons & pricing | Pixel Forge Studio",
      "Google Business Profile, Justdial, IndiaMART, WhatsApp API, AI bots, SEO and ads — all priced openly.", b, "add-ons.html")

# ---------------------------------------------------------------- WORK
def build_work():
    b = f"""
<main>
<section class="hero" style="padding:64px 0 40px">
  <div class="grid-bg"></div>
  <div class="wrap" style="position:relative;z-index:2">
    <span class="eyebrow"><span class="dot"></span>Our work</span>
    <h1 class="hero-title" style="font-size:clamp(2.2rem,4.6vw,3.6rem)">One client.<br><span class="grad">Live today.</span></h1>
    <p class="hero-sub">We are a new studio, so we show you one project in full rather than a wall of logos. Open it on your phone while you read this.</p>
  </div>
</section>

<section class="sec" style="padding-top:10px">
  <div class="wrap">
    <div class="bento">
      <div class="card c-7 rv" style="padding:0;overflow:hidden;display:grid;place-items:center;background:linear-gradient(160deg,#1B1512,#0C0A09);min-height:300px">
        <div style="width:82%;background:#080706;border:1px solid var(--line-2);border-radius:11px;overflow:hidden;box-shadow:0 30px 60px -20px #000">
          <div style="display:flex;gap:5px;padding:9px 11px;border-bottom:1px solid var(--line);align-items:center"><i style="width:6px;height:6px;border-radius:50%;background:#5A2A1A;display:block"></i><i style="width:6px;height:6px;border-radius:50%;background:#2E2822;display:block"></i><i style="width:6px;height:6px;border-radius:50%;background:#2E2822;display:block"></i><span style="font-family:'JetBrains Mono';font-size:.55rem;color:var(--ash-2);margin-left:8px">redapple repair</span></div>
          <div style="padding:30px 24px">
            <div style="font-family:'JetBrains Mono';font-size:.56rem;color:var(--ember);letter-spacing:.14em">HALASURU METRO ROAD · 560008</div>
            <div style="font-family:'Space Grotesk';font-weight:700;font-size:1.7rem;line-height:1.05;margin:10px 0 14px;letter-spacing:-.03em">Bring your device<br>back to factory glory.</div>
            <div style="height:5px;border-radius:3px;background:linear-gradient(90deg,var(--ember),var(--ember-soft));width:70%;margin-bottom:7px"></div>
            <div style="height:5px;border-radius:3px;background:var(--line);width:50%;margin-bottom:7px"></div>
            <div style="height:5px;border-radius:3px;background:var(--line);width:62%;margin-bottom:16px"></div>
            <div style="display:flex;gap:8px">
              <span style="font-size:.6rem;padding:7px 14px;border-radius:99px;background:var(--ember);color:#fff;font-weight:600">Book a repair</span>
              <span style="font-size:.6rem;padding:7px 14px;border-radius:99px;border:1px solid var(--line-2);color:var(--ash)">Call now</span>
            </div>
          </div>
        </div>
      </div>
      <div class="card c-5 rv" data-d="80">
        <span class="mono" style="color:var(--ember)">CASE STUDY · 2026</span>
        <h3 style="margin:10px 0 12px;font-size:1.5rem">Red Apple Mobile Repair</h3>
        <p style="font-size:.9rem">Independent Apple device repair lab in Indiranagar. They were fixing devices that authorised centres had declared dead — but online, they were invisible.</p>
        <table style="width:100%;font-size:.82rem;margin-top:14px">
          <tr><td style="color:var(--ash);padding:6px 0">Location</td><td style="text-align:right">Indiranagar, Bengaluru</td></tr>
          <tr><td style="color:var(--ash);padding:6px 0">Trading since</td><td style="text-align:right">2014</td></tr>
          <tr><td style="color:var(--ash);padding:6px 0">Google rating</td><td style="text-align:right;color:var(--ember)">4.9 ★</td></tr>
          <tr><td style="color:var(--ash);padding:6px 0">Reviews</td><td style="text-align:right;color:var(--ember)">767</td></tr>
          <tr><td style="color:var(--ash);padding:6px 0">Build time</td><td style="text-align:right;color:var(--ember)">7 days</td></tr>
        </table>
      </div>
    </div>
  </div>
</section>

<section class="sec sec-alt">
  <div class="wrap" style="max-width:820px">
    {sec_head("The brief", "Fix the invisible part.")}
    <p style="color:var(--ash)">Red Apple had everything a repair business needs except a way to be found. No website. A Google listing with strong reviews but no link to anywhere. Customers who discovered them by word of mouth and nothing else.</p>
    <h3 style="margin:28px 0 12px">What we built</h3>
    <ul style="color:var(--ash);font-size:.93rem;padding-left:20px">
      <li style="margin-bottom:9px">A five-page conversion-focused website — services, pricing, proof, contact — with a WhatsApp button on every page.</li>
      <li style="margin-bottom:9px">Google Business Profile setup and optimisation, linked to the new site.</li>
      <li style="margin-bottom:9px">Google Ads with full conversion tracking: phone clicks, WhatsApp clicks and form submits each recorded as a separate event.</li>
      <li style="margin-bottom:9px">Schema markup and a sitemap, so Google understands what the business does and where.</li>
    </ul>
    <h3 style="margin:28px 0 12px">What changed</h3>
    <p style="color:var(--ash)">For the first time, the studio could see which enquiries actually became walk-ins. Not "the site got traffic" — which specific channel produced which customer. That is the difference between marketing and guessing.</p>
    <div class="offer" style="margin-top:34px;text-align:left;padding:32px">
      <h3 style="margin-bottom:10px">Want the same for your business?</h3>
      <p style="margin-bottom:18px;max-width:none">We will design your homepage free, in 48 hours, before you pay anything.</p>
      <a class="btn btn-primary" href="contact.html">Start with a free mockup</a>
    </div>
  </div>
</section>
</main>
"""
    return page("work.html","Our work — Red Apple Mobile Repair case study | Pixel Forge Studio",
      "How we built a conversion-focused website and Google Ads tracking for Red Apple Mobile Repair, Indiranagar, in seven days.", b, "work.html")

# ---------------------------------------------------------------- ABOUT
def build_about():
    b = f"""
<main>
<section class="hero" style="padding:64px 0 40px">
  <div class="grid-bg"></div>
  <div class="wrap" style="position:relative;z-index:2">
    <span class="eyebrow"><span class="dot"></span>About</span>
    <h1 class="hero-title" style="font-size:clamp(2.2rem,4.6vw,3.6rem)">Why this<br><span class="grad">studio exists.</span></h1>
  </div>
</section>
<section class="sec" style="padding-top:10px">
  <div class="wrap" style="max-width:760px">
    <div class="rv">
      <p style="font-size:1.1rem;color:var(--bone);line-height:1.7">I'm Faisal Wahaab, founder of Pixel Forge Studio.</p>
      <p style="color:var(--ash);font-size:1rem">I started this studio because I kept meeting good Bengaluru businesses — a salon in Indiranagar, a clinic in Jayanagar, a repair shop in Indiranagar — who were losing customers simply because they were invisible online. Not because their work was bad. Because nobody had built them anything decent.</p>
      <p style="color:var(--ash);font-size:1rem">Agencies quoted them six weeks and two lakhs. Freelancers disappeared halfway. So we built a studio that ships in seven days, on the same modern stack the big product companies use, and hands over every file, every account, every key.</p>
      <p style="color:var(--ash);font-size:1rem">You own everything. There are no hidden costs. And every site we build includes an AI assistant that answers your customers at 11pm, when you're asleep.</p>
      <p style="font-size:1.1rem;color:var(--bone)">That's the whole promise. Seven days, everything yours.</p>
      <p style="font-family:'Space Grotesk';font-size:1rem;color:var(--ember);margin-top:22px">— Faisal Wahaab, Founder</p>
    </div>
    <div class="card rv" style="margin-top:38px;border-color:rgba(var(--ember-rgb),.3)">
      <span class="mono" style="color:var(--ember)">Registered enterprise</span>
      <h3 style="margin:10px 0 8px">Pixel Forge Studio is a registered business.</h3>
      <p style="font-size:.9rem;margin-bottom:14px">Registered with the Ministry of Micro, Small and Medium Enterprises, Government of India. The registration can be verified independently on the Udyam portal — we would rather you check than take our word for it.</p>
      <table style="width:100%;font-size:.84rem;max-width:520px">
        <tr><td style="color:var(--ash);padding:6px 0">Udyam number</td><td style="text-align:right;font-family:'JetBrains Mono';color:var(--ember)">UDYAM-KA-03-0460058</td></tr>
        <tr><td style="color:var(--ash);padding:6px 0">Registered</td><td style="text-align:right">10 October 2023</td></tr>
        <tr><td style="color:var(--ash);padding:6px 0">Registered office</td><td style="text-align:right">Shivajinagar, Bengaluru 560051</td></tr>
      </table>
    </div>

    <div class="bento" style="margin-top:26px">
      <div class="card c-4 rv"><span class="n">01</span><h3>You own it</h3><p>Code, repository, domain, hosting, every account — in your name, from day one.</p></div>
      <div class="card c-4 rv" data-d="80"><span class="n">02</span><h3>Fixed price</h3><p>Published on this site. No "contact us for a quote" and no invoice surprises.</p></div>
      <div class="card c-4 rv" data-d="160"><span class="n">03</span><h3>Seven days</h3><p>From content handover to live. If we miss it because of us, you do not pay.</p></div>
    </div>
  </div>
</section>
</main>
"""
    return page("about.html","About Pixel Forge Studio — Faisal Wahaab, Bengaluru",
      "Why Pixel Forge Studio exists: good Bengaluru businesses losing customers because nobody built them anything decent.", b, "about.html")

# ---------------------------------------------------------------- PROCESS
def build_process():
    steps = [
      ("01","Free mockup","48 hours","You send your business name, services and city. We design a real homepage — not a wireframe — and send it. No card, no commitment."),
      ("02","Agree the scope","1 day","Fixed price, fixed date, in writing. You pay 50% to start. The clock starts when we have your content and photos."),
      ("03","Forge","4 days","Design, development, copy, tracking. You get a staging link on day two so you are never guessing what is happening."),
      ("04","Review","1 day","Two full rounds of changes. Anything broken, we fix it. Anything you dislike, we change it."),
      ("05","Handover","1 day","Site goes live. You get the repository, domain, hosting, analytics and every account — plus a walkthrough video."),
    ]
    blocks = "".join(f"""
      <div class="rv" style="display:grid;grid-template-columns:90px 1fr;gap:24px;padding:28px 0;border-bottom:1px solid var(--line)">
        <div><span style="font-family:'Space Grotesk';font-size:2rem;color:var(--ember);line-height:1">{n}</span>
        <div style="font-family:'JetBrains Mono';font-size:.64rem;color:var(--ash-2);letter-spacing:.1em;margin-top:6px">{t}</div></div>
        <div><h3 style="margin-bottom:8px">{title}</h3><p style="color:var(--ash);font-size:.93rem;margin:0">{d}</p></div>
      </div>""" for n,title,t,d in steps)

    b = f"""
<main>
<section class="hero" style="padding:64px 0 40px">
  <div class="grid-bg"></div>
  <div class="wrap" style="position:relative;z-index:2">
    <span class="eyebrow"><span class="dot"></span>Process</span>
    <h1 class="hero-title" style="font-size:clamp(2.2rem,4.6vw,3.6rem)">Five steps.<br><span class="grad">Seven days.</span></h1>
    <p class="hero-sub">No mystery, no "we'll keep you posted". Here is exactly what happens, and when.</p>
  </div>
</section>
<section class="sec" style="padding-top:10px">
  <div class="wrap" style="max-width:820px">{blocks}</div>
</section>
<section class="sec sec-alt">
  <div class="wrap" style="max-width:820px">
    {sec_head("The promise", "On time, or it's free.")}
    <div class="bento">
      <div class="card c-6 rv"><h3>Single website or CRM</h3><p style="margin-top:8px">Live by the agreed date, or the project fee is refunded in full.</p></div>
      <div class="card c-6 rv" data-d="80"><h3>App or stack</h3><p style="margin-top:8px">Milestone-based. Miss one by more than 7 days and that milestone's payment is waived.</p></div>
    </div>
    <p style="color:var(--ash-2);font-size:.8rem;margin-top:18px">The clock starts when we have your content and the advance. Delays caused by pending content, feedback or approvals shift the date day for day.</p>
  </div>
</section>
</main>
"""
    return page("process.html","Our process — five steps, seven days | Pixel Forge Studio",
      "Exactly how a Pixel Forge build runs: free mockup, fixed scope, four days of build, review, handover.", b, "process.html")

# ---------------------------------------------------------------- FAQ
def build_faq():
    qs = [
      ("How can you deliver in seven days when agencies take six weeks?","Because we removed everything that makes projects slow: no committee, no handoffs between three teams, no waiting on a designer in another timezone. One studio, one design system, one build. We also use AI in our own workflow — that is why seven days is possible, not why it is cheap."),
      ("What if I do not like the design?","You see a real homepage before you pay anything. If it is not right, you keep it and we part as friends. On a paid build you get two full rounds of changes at the review stage; if it is still wrong, we refund the balance."),
      ("Do I own the website and the code?","Completely. Source code, repository, domain, hosting, analytics, Google Ads — all in your name. No lock-in, and no fee to keep your own site."),
      ("What happens after seven days?","Three months of care is included free: uptime monitoring, backups, security patches and content updates. After month three it continues at ₹2,499 a month, and only if you want it. No auto-renewal."),
      ("Do you work with businesses outside Bengaluru?","Yes. Most of our work is remote — calls, screen shares and WhatsApp. We have worked with clients across India. Being in Bengaluru helps for photography and local SEO, but it is not a requirement."),
      ("What is included in the AI assistant?","A chat widget on your site trained on your services, prices, timings and policies. It answers customers, captures their name and number, and hands off to you on WhatsApp when it is unsure. It is updated monthly from real conversations."),
      ("Can I pay in instalments?","Yes. 50% to start, 50% on launch. For stacks and apps we split payment across milestones — you pay for each stage as it is delivered."),
      ("What do you need from me to start?","Your logo if you have one, three to five photographs, your services with prices, your business hours and your WhatsApp number. If you do not have photos, we source licensed images and swap them later."),
    ]
    items = "".join(f'<div class="faq-item"><button class="faq-q">{q}<span class="pm">+</span></button><div class="faq-a"><p>{a}</p></div></div>' for q,a in qs)
    b = f"""
<main>
<section class="hero" style="padding:64px 0 40px">
  <div class="grid-bg"></div>
  <div class="wrap" style="position:relative;z-index:2">
    <span class="eyebrow"><span class="dot"></span>FAQ</span>
    <h1 class="hero-title" style="font-size:clamp(2.2rem,4.6vw,3.6rem)">Straight<br><span class="grad">answers.</span></h1>
    <p class="hero-sub">The eight questions we get asked most, answered without the sales voice.</p>
  </div>
</section>
<section class="sec" style="padding-top:10px">
  <div class="wrap" style="max-width:820px"><div class="faq">{items}</div></div>
</section>
<section class="sec sec-alt">
  <div class="wrap"><div class="offer rv">
    <h2>Still unsure?</h2><p>Ask the assistant in the corner, or message Faisal directly. We reply within five minutes during business hours.</p>
    <a class="btn btn-primary" href="contact.html">Talk to us</a>
  </div></div>
</section>
</main>
"""
    return page("faq.html","FAQ | Pixel Forge Studio",
      "How we deliver in seven days, who owns the code, what happens after launch, and what we need from you.", b, "faq.html")

# ---------------------------------------------------------------- CONTACT
def build_contact():
    b = f"""
<main>
<section class="hero" style="padding:64px 0 40px">
  <div class="grid-bg"></div>
  <div class="wrap" style="position:relative;z-index:2">
    <span class="eyebrow"><span class="dot"></span>Contact</span>
    <h1 class="hero-title" style="font-size:clamp(2.2rem,4.6vw,3.6rem)">Tell us what<br><span class="grad">you need built.</span></h1>
    <p class="hero-sub">One line is enough to start. We will reply with a straight answer, not a brochure.</p>
  </div>
</section>
<section class="sec" style="padding-top:10px">
  <div class="wrap">
    <div class="bento">
      <div class="card c-7 rv">
        <h3 style="margin-bottom:18px">Send a message</h3>
        <form name="enquiry" method="POST" data-netlify="true" action="/thanks.html">
          <input type="hidden" name="form-name" value="enquiry">
          <div style="display:grid;gap:12px">
            <input name="name" placeholder="Your name" required style="background:var(--ink);border:1px solid var(--line);border-radius:9px;padding:12px 14px;color:var(--bone);font-family:inherit;font-size:.9rem;outline:none">
            <input name="business" placeholder="Business name" style="background:var(--ink);border:1px solid var(--line);border-radius:9px;padding:12px 14px;color:var(--bone);font-family:inherit;font-size:.9rem;outline:none">
            <input name="phone" placeholder="WhatsApp number" required style="background:var(--ink);border:1px solid var(--line);border-radius:9px;padding:12px 14px;color:var(--bone);font-family:inherit;font-size:.9rem;outline:none">
            <select name="need" style="background:var(--ink);border:1px solid var(--line);border-radius:9px;padding:12px 14px;color:var(--bone);font-family:inherit;font-size:.9rem;outline:none">
              <option>Website</option><option>CRM</option><option>App</option>
              <option>Website + CRM</option><option>All three</option><option>Add-ons only</option>
            </select>
            <textarea name="message" rows="4" placeholder="What do you need? One line is fine." style="background:var(--ink);border:1px solid var(--line);border-radius:9px;padding:12px 14px;color:var(--bone);font-family:inherit;font-size:.9rem;outline:none;resize:vertical"></textarea>
            <button class="btn btn-primary btn-block" type="submit">Send message</button>
          </div>
        </form>
      </div>
      <div class="card c-5 rv" data-d="80">
        <h3 style="margin-bottom:16px">Or skip the form</h3>
        <a class="btn btn-primary btn-block" href="https://wa.me/{WA}?text=Hi%20Faisal%2C%20I%20need%20a%20website." target="_blank" rel="noopener" style="margin-bottom:12px">WhatsApp us</a>
        <table style="width:100%;font-size:.84rem;margin-top:18px">
          <tr><td style="color:var(--ash);padding:7px 0">Phone</td><td style="text-align:right">+91 96200 24812</td></tr>
          <tr><td style="color:var(--ash);padding:7px 0">Email</td><td style="text-align:right">hello@pixelforgestudio.com</td></tr>
          <tr><td style="color:var(--ash);padding:7px 0">Hours</td><td style="text-align:right">Mon–Sat, 10am–7pm</td></tr>
          <tr><td style="color:var(--ash);padding:7px 0">Reply time</td><td style="text-align:right;color:var(--ok)">under 5 minutes</td></tr>
          <tr><td style="color:var(--ash);padding:7px 0">Office</td><td style="text-align:right;font-size:.78rem">No 53, 5th House B Street,<br>Shivajinagar, Broadway,<br>Bengaluru 560051</td></tr>
          <tr><td style="color:var(--ash);padding:7px 0">Udyam</td><td style="text-align:right;font-family:'JetBrains Mono';font-size:.72rem;color:var(--ember)">UDYAM-KA-03-0460058</td></tr>
        </table>
        <p style="font-size:.76rem;color:var(--ash-2);margin-top:18px">We are based in Bengaluru. Most work is done remotely with calls and screen shares.</p>
      </div>
    </div>
  </div>
</section>
</main>
"""
    return page("contact.html","Contact | Pixel Forge Studio Bengaluru",
      "Tell us what you need built. WhatsApp, phone or form — we reply within five minutes during business hours.", b, "contact.html")

# ---------------------------------------------------------------- LEGAL
def legal_page(fn, title, desc, body, active):
    b = f"""
<main>
<section class="sec" style="padding-top:56px">
  <div class="wrap legal">
    <span class="updated">Last updated 26 October 2026</span>
    <h1 style="font-size:clamp(1.9rem,3.4vw,2.6rem);margin:14px 0 10px">{title}</h1>
    <p style="color:var(--ash)">{desc}</p>
    {body}
    <p style="margin-top:40px;font-size:.8rem;color:var(--ash-2)">Pixel Forge Studio · Udyam UDYAM-KA-03-0460058 · No 53, 5th House B Street, Shivajinagar, Broadway, Bengaluru 560051.<br>Questions about this policy? Email hello@pixelforgestudio.com or call +91 96200 24812.</p>
  </div>
</section>
</main>"""
    return page(fn, f"{title} | Pixel Forge Studio", desc, b, active)

def build_privacy():
    body = """
<h2>What we collect</h2>
<p>When you contact us we collect your name, business name, phone number and whatever you tell us in your message. When you visit this site we collect anonymous usage data — pages viewed, device type and approximate location — through Google Analytics.</p>
<h2>Why we collect it</h2>
<ul><li>To reply to your enquiry and quote for work</li><li>To deliver a project you have commissioned</li><li>To send invoices and project updates</li><li>To improve this website</li></ul>
<h2>What we never do</h2>
<ul><li>We do not sell your data to anyone</li><li>We do not send marketing messages you did not ask for</li><li>We do not share client data with other clients</li></ul>
<h2>Cookies</h2>
<p>This site uses cookies for analytics and to remember your preferences. You can block cookies in your browser settings; the site will still work.</p>
<h2>How long we keep it</h2>
<p>Enquiry data is kept for 24 months. Project files and invoices are kept for seven years as required by Indian tax law.</p>
<h2>Your rights</h2>
<p>You can ask us to show you what we hold about you, correct it, or delete it. Email hello@pixelforgestudio.com and we will respond within 30 days.</p>
<h2>Third parties</h2>
<p>We use Google Analytics, Netlify for hosting and WhatsApp Business for messaging. Each has its own privacy policy. Client project data is stored in accounts registered to the client, not to us.</p>
"""
    return legal_page("privacy.html","Privacy Policy","How Pixel Forge Studio collects, uses and protects your information.",body,"")

def build_refund():
    body = """
<h2>Free mockup</h2>
<p>Before any payment, we design a homepage for your business. It is yours to keep whether or not you proceed. There is no charge and no obligation.</p>
<h2>Project payments</h2>
<p>Projects are paid 50% to begin and 50% on launch. Stacks and apps are split across milestones, with each milestone paid on delivery.</p>
<h2>Cancellation by you</h2>
<ul><li><strong>Before work begins:</strong> full refund of any advance.</li><li><strong>Within the first 48 hours of build:</strong> 50% refund of the advance.</li><li><strong>After 48 hours:</strong> the advance covers work already completed and is not refundable, but you receive all files produced so far.</li></ul>
<h2>Our guarantee</h2>
<p>If we miss the agreed launch date because of us, the project fee is refunded in full for single website or CRM builds. For apps and stacks, the guarantee is milestone-based: miss a milestone by more than seven days and that milestone's payment is waived.</p>
<p>The clock starts when we have your content, photos and advance. Delays caused by pending content, feedback or approvals shift the date day for day.</p>
<h2>What is not refundable</h2>
<ul><li>Third-party costs already paid on your behalf — domain registration, hosting, platform fees, ad spend, directory listing fees</li><li>Work delivered and approved at the review stage</li><li>Monthly care plans after the month has begun</li></ul>
<h2>How to request a refund</h2>
<p>Email hello@pixelforgestudio.com with your project name and reason. We respond within 5 working days and process approved refunds within 10 working days to the original payment method.</p>
"""
    return legal_page("refund.html","Refund Policy","Our refund terms, the seven-day guarantee and what is not refundable.",body,"")

def build_terms():
    body = """
<h2>1. Scope of work</h2>
<p>Each project is defined in a written proposal listing deliverables, price and delivery date. Anything not listed is out of scope and quoted separately.</p>
<h2>2. Payment</h2>
<p>50% on acceptance, 50% on launch, unless a milestone schedule is agreed in writing. Invoices are due within 7 days. Work may pause on overdue invoices.</p>
<h2>3. Your responsibilities</h2>
<p>You agree to provide content, photographs, logos and feedback within reasonable time. Delivery dates assume content is supplied at the start. Delays in content shift the delivery date day for day.</p>
<h2>4. Intellectual property</h2>
<p>On final payment, all custom code, design and content created for you transfers to you outright. You own the repository, domain, hosting and every account. We retain the right to reference the project in our portfolio unless you ask us not to in writing.</p>
<h2>5. Third-party services</h2>
<p>Domains, hosting, payment gateways, WhatsApp API and advertising platforms are billed to you directly and governed by their own terms. We are not responsible for outages, policy decisions or price changes by those providers.</p>
<h2>6. Care plans</h2>
<p>Care plans are monthly and cancel with 30 days notice. They cover monitoring, backups, security patches and the updates listed in your plan. They do not cover new features, which are quoted separately.</p>
<h2>7. Limitation of liability</h2>
<p>Our total liability for any claim is limited to the fees paid for the specific project. We are not liable for lost profit, lost data or indirect losses.</p>
<h2>8. AI features</h2>
<p>AI assistants answer from a knowledge base you approve. They may occasionally give incomplete answers. We review and update the knowledge base monthly. AI assistants do not make commitments on your behalf and always offer a route to a human.</p>
<h2>9. Governing law</h2>
<p>These terms are governed by the laws of India. Disputes are subject to the jurisdiction of courts in Bengaluru, Karnataka.</p>
<h2>10. Changes</h2>
<p>We may update these terms. The version in force is the one published here on the date your project begins.</p>
"""
    return legal_page("terms.html","Terms of Service","The terms governing Pixel Forge Studio projects and services.",body,"")

# ---------------------------------------------------------------- PWA + RUN
MANIFEST = '''{
  "name": "Pixel Forge Studio",
  "short_name": "Pixel Forge",
  "description": "Modern websites, Forged In 7 Days. Bengaluru studio.",
  "start_url": "./index.html",
  "scope": "./",
  "display": "standalone",
  "background_color": "#0A0908",
  "theme_color": "#0A0908",
  "icons": [
    { "src": "assets/img/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable" },
    { "src": "assets/img/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable" }
  ]
}'''

SW = '''const C = 'pf-v1';
const ASSETS = ['./','./index.html','./services.html','./packages.html','./add-ons.html','./work.html','./about.html','./process.html','./faq.html','./contact.html','./assets/css/style.css','./assets/js/main.js'];
self.addEventListener('install', e => { e.waitUntil(caches.open(C).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== C).map(x => caches.delete(x)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  if (e.request.mode === 'navigate') {
    e.respondWith(fetch(e.request).then(r => { const cp = r.clone(); caches.open(C).then(c => c.put(e.request, cp)); return r; }).catch(() => caches.match(e.request).then(r => r || caches.match('./index.html'))));
    return;
  }
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request).then(res => { const cp = res.clone(); caches.open(C).then(c => c.put(e.request, cp)); return res; })));
});'''

def build_thanks():
    b = """
<main><section class="sec" style="min-height:62vh;display:grid;place-items:center">
<div class="wrap" style="text-align:center;max-width:560px">
<div style="width:64px;height:64px;border-radius:18px;background:rgba(74,222,128,.12);border:1px solid rgba(74,222,128,.3);display:grid;place-items:center;margin:0 auto 22px">
<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#4ADE80" stroke-width="2.2"><path d="M20 6L9 17l-5-5"/></svg></div>
<h1 style="font-size:clamp(1.8rem,4vw,2.6rem);margin-bottom:12px">Message received.</h1>
<p style="color:var(--ash);margin-bottom:26px">We reply within five minutes during business hours. If it is urgent, WhatsApp is faster.</p>
<a class="btn btn-primary" href="https://wa.me/919620024812?text=Hi%20Faisal%2C%20I%20just%20sent%20an%20enquiry.">Open WhatsApp</a>
<a class="btn btn-ghost" href="index.html" style="margin-left:8px">Back to home</a>
</div></section></main>
"""
    return page("thanks.html","Message sent | Pixel Forge Studio","We have received your enquiry and will reply within five minutes during business hours.", b, "contact.html")

def build_404():
    b = """
<main><section class="sec" style="min-height:62vh;display:grid;place-items:center">
<div class="wrap" style="text-align:center;max-width:560px">
<span class="eyebrow"><span class="dot"></span>404</span>
<h1 style="font-size:clamp(2rem,5vw,3.2rem);margin:18px 0 12px">This page was never forged.</h1>
<p style="color:var(--ash);margin-bottom:26px">The link is broken or the page has moved. Everything we actually build is on the home page.</p>
<a class="btn btn-primary" href="index.html">Back to home</a>
<a class="btn btn-ghost" href="packages.html" style="margin-left:8px">See packages</a>
</div></section></main>
"""
    return page("404.html","Page not found | Pixel Forge Studio","That page does not exist. Head back to the home page.", b, "index.html")

def main():
    built = [
        build_home(), build_services(), build_packages(), build_addons(),
        build_work(), build_about(), build_process(), build_faq(), build_contact(),
        build_privacy(), build_refund(), build_terms(),
        build_thanks(), build_404(),
    ]
    PAGES = ["", "services.html", "packages.html", "add-ons.html", "work.html", "about.html",
             "process.html", "faq.html", "contact.html", "privacy.html", "refund.html", "terms.html"]
    urls = "".join(f"  <url><loc>https://pixelforgestudio.com/{p}</loc><changefreq>monthly</changefreq></url>\n" for p in PAGES)
    (OUT / "sitemap.xml").write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + urls + '</urlset>\n', encoding="utf-8")
    (OUT / "robots.txt").write_text(
        "User-agent: *\nAllow: /\n\nSitemap: https://pixelforgestudio.com/sitemap.xml\n", encoding="utf-8")
    (OUT / "manifest.json").write_text(MANIFEST, encoding="utf-8")
    (OUT / "sw.js").write_text(SW, encoding="utf-8")
    total = 0
    for f in sorted(built):
        p = OUT / f
        total += p.stat().st_size
        print(f"  {f:18} {p.stat().st_size//1024:4} KB")
    print(f"\n{len(built)} pages · {total//1024} KB HTML")

if __name__ == "__main__":
    main()
